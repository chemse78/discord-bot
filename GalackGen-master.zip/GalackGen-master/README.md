<img alt="GalackGen" src="https://i.imgur.com/HKodxPv.png">  

[![](https://img.shields.io/discord/745382663896039496.svg?logo=discord&colorB=7289DA)](https://discord.gg/XH7zQ8s)
[![](https://img.shields.io/badge/discord.js-v12.0.0--dev-blue.svg?logo=npm)](https://github.com/discordjs)
[![](https://img.shields.io/badge/paypal-donate-blue.svg)](https://paypal.me/GalackQSM)

GalackGen est un bot Discord de génération de compte open source codé en JavaScript avec [Discord.js](https://discord.js.org) par [GalackQSM](https://github.com/GalackQSM).  
N'hésitez pas à ajouter une étoile ⭐ au référentiel pour promouvoir le projet!

### Bot

Offres GalackGen:
*   ✉️ Vous pouvez crée vos propre compte
*   🇫🇷 Marche que sur un seul salon pour évité le spam
*   ⚙️ Chaque compte généré et directement supprimer

### Commandes

* gen (Nom du service) - Générer des comptes
* create (Nom du service) - Créer un service
* restock (Nom du service) (Nombre de compte) - Notifier les restocks de compte
* add (mail:pass) (Nom du service) - Ajouter des comptes
* stats - Afficher les statistiques de GalackGen

## Installation

* Aller dans le fichier `config.json` et mettez le bot de votre bot
* Toujours dans le fichier `config.json` dans `botChannel`mettez l'id du salon ou seul le bot pourras fonctionner
* Ensuite allez dans CMD et faite `node index.js`

Pour restock des comptes, vous pouvez directement les restocks a partir du fichier sans redémarrer votre bot, dans le dossier `comptes`
## Liens

*   [Discord](https://discord.gg/XH7zQ8s)
*   [Twitter](https://twitter.com/Galack_QSM)
*   [Github](https://github.com/GalackQSM/)

[![TUTORIEL](https://img.youtube.com/vi/YEek_20O9Co/0.jpg)](https://www.youtube.com/watch?v=YEek_20O9Co)
